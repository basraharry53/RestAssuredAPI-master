package com.weather.enums;
/**
 *
 * @author  harpreet basra
 *
 */
public enum Context {
    Status_Code,
    Response_body
}