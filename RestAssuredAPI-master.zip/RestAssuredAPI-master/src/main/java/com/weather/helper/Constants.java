package com.weather.helper;

/**
 * 
 * @author harpreet basra
 *
 */
public class Constants {

	public static final String mainUrl="https://www.anz.com.au/personal/home-loans/calculators-tools/much-borrow/";
	public final static long explicitWait = 100;
	public final static long impliciteWait = 100;
}
